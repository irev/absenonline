@extends('index')
@section('title','Pimpinan')
@section('content')
    @php $i=1; @endphp
    <table>
        <tr>
            <th width="5%" align="center">No</th>
            <th width="35%" align="left">Nama</th>
            <th width="15%" align="center">Masuk</th>
            <th width="15%" align="center">Pulang</th>
            <th width="15%">Server</th>
        </tr>
        @foreach($pimpinan->data as $pm) 
            @foreach($absen1 as $ab)
                @if($pm->id_user === $ab['id_user'])
                <tr> 
                    <td align="center">{{$i++}}</td> 
                    <td>{{$ab['nama_lengkap']}}</td>
                    <td align="center">{{$ab['timestamp_masuk']}}</td>
                    <td @if($ab['timestamp_pulang'] == null) style="background-color:pink" @endif align="center">{{$ab['timestamp_pulang']}}</td> 
                    <td align="center">SERVER 1</td>
                </tr>
                @endif
            @endforeach  
            @foreach($absen2 as $ab)
                @if($pm->id_user === $ab['id_user'])
                    <tr> 
                        <td align="center">{{$i++}}</td> 
                        <td>{{$ab['nama_lengkap']}}</td>
                        <td align="center">{{$ab['timestamp_masuk']}}</td>
                        <td @if($ab['timestamp_pulang'] == null) style="background-color:pink" @endif align="center">{{$ab['timestamp_pulang']}}</td> 
                        <td align="center">SERVER 3</td>
                    </tr>
                @endif
            @endforeach 
            @foreach($absen3 as $ab)
                @if($pm->id_user === $ab['id_user'])
                    <tr> 
                        <td align="center">{{$i++}}</td> 
                        <td>{{$ab['nama_lengkap']}}</td>
                        <td align="center">{{$ab['timestamp_masuk']}}</td>
                        <td @if($ab['timestamp_pulang'] == null) style="background-color:pink" @endif align="center">{{$ab['timestamp_pulang']}}</td> 
                        <td align="center">SERVER 3</td>
                    </tr>
                @endif
            @endforeach 
        @endforeach
    </table>  
@endsection