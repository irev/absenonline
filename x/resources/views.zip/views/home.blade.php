@extends('index')
@section('title','Home')
@section('content') 
    @php $i=1; @endphp 
    <table>
        <tr>
            <th>No</th>
            <th>Nama Instansi</th> 
            <th>Total Absen</th> 
        </tr>   
    @foreach ($admin->data as $row)  
        @if(substr($row->nama_instansi,0,3) !== "Kec" && 
        substr($row->nama_instansi,0,3) !== "Sek" && 
        substr($row->nama_instansi,0,3) !== "UPT" && 
        substr($row->nama_instansi,0,3) !== "Kab" && 
        substr($row->nama_instansi,0,3) !== "kec")   
            <tr> 
                <td>{{$i++}}</td>  
                <td><a href="{{url('opd/'.$row->id_user)}}" style="text-transform: uppercase">{{$row->nama_instansi}}</a></td>
                <td>
                    <!-- @forelse ($absen as $ab)  
                        @if($row->id_user == $ab['id_admin_instansi']) 
                                {{$ab['nama_lengkap']}} <br> 
                        @endif  
                    @empty
                        <tr> 
                            <td>{{$i++}}</td>  
                            <td><a href="{{$row->id_user}}">{{$row->nama_instansi}}</a></td>
                            <td></td>  
                        </tr>
                    @endforelse -->
                </td>  
             </tr>  
        @endif
    @endforeach 
    </table>  
@endsection
<!-- style="text-transform: uppercase" -->