<?php


class Dashboard_controller extends CI_Controller{

    function __construct(){
        parent::__construct();
       
        if($this->session->userdata('masuk') != TRUE){
                redirect('/login_controller');
            }
            $this->load->model('Dashboard_model');
            $this->load->model('Absen_model');
      } 

    public function index(){
        $data['riwayat_absen'] = $this->Dashboard_model->getRiwayatAbsenHariIni();
        $data['total_riwayat_absen'] = $this->Dashboard_model->getTotalRiwayatAbsenHariIni();
        $data['adminOPD'] = $this->Absen_model->getAdminOPD();
        
        $this->load->view('_partials/head');
        $this->load->view('_partials/sidebar', $data);
		$this->load->view('_partials/header');
		$this->load->view('v_dashboard', $data);
		$this->load->view('_partials/js');
    }


    
}