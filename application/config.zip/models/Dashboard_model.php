<?php




class Dashboard_model extends CI_model{


    public function getRiwayatAbsenHariIni(){
        $id_admin_instansi = $this->session->userdata('id_user');
        $array = array('tgl_absen' => date("Y-m-d"),'id_admin_instansi' => $id_admin_instansi);
        $this->db->select('*,(TIMEDIFF(timestamp_masuk,timestamp_pulang)) as `jam_kerja`');
        return $this->db->get_where('absen5',$array)->result_array();
        //return $this->db->get('absen')->result_array();

    }


    
    public function getTotalRiwayatAbsenHariIni(){
        $id_admin_instansi = $this->session->userdata('id_user');
        $array = array('tgl_absen' => date("Y-m-d"),'id_admin_instansi' => $id_admin_instansi, 'status' => '1');
        return  $this->db->get_where('absen5', $array)->num_rows();
        //return $this->db->get('absen')->result_array();
    }

    

}
