 
<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="row">
                            <div class="col-xl-12 col-md-12 m-b-30">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent"> 
                                    <div class="tab-pane fade active show" id="profile" role="tabpanel" aria-labelledby="home-tab">
                                        <h4 class="nama_instansi"> 
                                        </h4>
                                        <div class="row"> 
                                        
                                        </div>
                                        <div class="table-responsive">
                                        <table class="table table-hover data-user">
                                            <thead>
                                                <tr>
                                                    <th>Nomor</th>
                                                    <th>Judul</th>
                                                    <th>Tanggal Terbit</th> 
                                                    <th class="text-right">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 

                                            </tbody>
                                        </table>
                                        <pre> 
                                        </pre>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
